function plot_axis_thru_origin()

lnx=line(get(gca,'xlim'),[0 0]); lny=line([0 0],get(gca,'ylim'));
