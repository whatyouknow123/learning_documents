模板持续更新，请及时到如下网址进行更新！
项目网址:
   https://github.com/ywgATustcbbs?tab=repositories
备份网址:
   https://gitlab.lug.ustc.edu.cn/ywg/ustcthesis

新手请仔细阅读《第一次接触LaTeX？读我》

请安装texlive2013或更新的texlive发行版，目前已知CTeX套装和本模板存在一定的兼容问题。CTeX套装最后更新是在2012年，并且之后并入texlive发行，不在单独发布！

开始撰写论文之前请仔细阅读main.pdf和main.tex以及chapter下的各章节，其中有许多基础代码示例可供参考

关于模板更详细的情况请查看main.pdf
pdf文件中没有代码示例的，可以参考main.tex、各章节源文件以及其注释